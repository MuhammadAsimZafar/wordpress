<div class="pinhole-pagination alignnone">
	<nav class="navigation prev-next">
		<div class="prev"><?php previous_posts_link( __pinhole( 'newer_entries' ) ); ?></div>
		<div class="next"><?php next_posts_link( __pinhole( 'older_entries' ) ); ?></div>
	</nav>
</div>