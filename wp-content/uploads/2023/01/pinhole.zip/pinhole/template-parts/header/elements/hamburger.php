<?php $class_hidden = pinhole_header_display('sidebar') ? '' : 'pinhole-mobile-visible'; ?>
<ul class="<?php echo esc_attr( $class_hidden ); ?>">
	<li><a href="javascript:void(0);" class="pinhole-action-sidebar"><i class="fa fa-bars"></i></a></li>
</ul>
