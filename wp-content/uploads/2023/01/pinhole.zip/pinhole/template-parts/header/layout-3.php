<div class="slot-l pinhole-header-3">
	<?php get_template_part('template-parts/header/elements/branding'); ?>

</div>
<div class="slot-c">

	<?php get_template_part('template-parts/header/elements/nav'); ?>
</div>
<div class="slot-r">
	<?php get_template_part('template-parts/header/elements/social'); ?>
	<?php get_template_part('template-parts/header/elements/search'); ?>
	<?php get_template_part('template-parts/header/elements/hamburger'); ?>
</div>